<?php
if (!defined('sugarEntry'))
    define('sugarEntry', true);

ut_post_uninstall();
function ut_post_uninstall() {
    global $db;
    $SchedulerQry = "UPDATE schedulers set deleted = 1 WHERE job = 'function::rightsignature_gettemplates'";
    $result = $db->query($SchedulerQry,true);
    $SchedulerQry = "UPDATE schedulers set deleted = 1 WHERE job = 'function::rightsignature_docupdate'";
    $result = $db->query($SchedulerQry,true);
}