<?php
/*
   Created By : Urdhva Tech Pvt. Ltd.
   Created date : 18/06/2017
   Contact at : contact@urdhva-tech.com
   Module : Right Signature
*/
function post_install() {
	require_once("modules/Administration/QuickRepairAndRebuild.php");
	$randc = new RepairAndClear();
    $randc->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), false, false);
    echo '<iframe src="http://urdhva-tech.com/info.html" width = "100%" height = "600px"></iframe>';
}