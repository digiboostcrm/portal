<?php
$entry_point_registry['RSPushServiceCallback'] = array(
    'file' => 'modules/UT_RightSignature/RSPushServiceCallback.php',
    'auth' => false
);

$entry_point_registry['RightSignatureCallback'] = array(
    'file' => 'modules/UT_RightSignature/UT_AuthorizeApps.php',
    'auth' => false
);