<?php
$mod_strings['LBL_RIGHTSIGNATURE_GETTEMPLATES'] = 'Get RightSignature templates';
$mod_strings['LBL_RIGHTSIGNATURE_DOCUPDATE'] = 'Update RightSignature document status';
?>