<?php
// created: 2017-06-22 13:57:06
$dictionary["Lead"]["fields"]["ut_rightsignature_leads_1"] = array (
  'name' => 'ut_rightsignature_leads_1',
  'type' => 'link',
  'relationship' => 'ut_rightsignature_leads_1',
  'source' => 'non-db',
  'module' => 'UT_RightSignature',
  'bean_name' => 'UT_RightSignature',
  'vname' => 'LBL_UT_RIGHTSIGNATURE_LEADS_1_FROM_UT_RIGHTSIGNATURE_TITLE',
);
