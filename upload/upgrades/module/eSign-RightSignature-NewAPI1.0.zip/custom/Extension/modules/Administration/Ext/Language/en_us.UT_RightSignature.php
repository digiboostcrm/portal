<?php 
$mod_strings['LBL_UT_RIGHTSIGNATURE_KEY_TITLE'] = 'Manage the API keys and Authorization';
$mod_strings['LBL_UT_RIGHTSIGNATURE_DESC'] = 'Configurations settings for Right Signature integration.';
$mod_strings['LBL_UT_RIGHTSIGNATURE_TITLE'] = 'eSign - RightSignature configuration';
$mod_strings['LBL_UT_RIGHTSIGNATURE_KEY_ICON'] = 'API Keys';

$mod_strings['LBL_ESIGN_RIGHSIGNATURE_LICENSE'] = 'eSign RightSignature License';
$mod_strings['LBL_ESIGN_RIGHSIGNATURE_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_ESIGN_RIGHSIGNATURE_DESC'] = 'Manage and configure the license for eSign RightSignature';