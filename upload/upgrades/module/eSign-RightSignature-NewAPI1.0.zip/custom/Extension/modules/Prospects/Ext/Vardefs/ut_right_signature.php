<?php
// created: 2017-06-22 13:58:40
$dictionary["Prospect"]["fields"]["ut_rightsignature_prospects_1"] = array (
  'name' => 'ut_rightsignature_prospects_1',
  'type' => 'link',
  'relationship' => 'ut_rightsignature_prospects_1',
  'source' => 'non-db',
  'module' => 'UT_RightSignature',
  'bean_name' => 'UT_RightSignature',
  'vname' => 'LBL_UT_RIGHTSIGNATURE_PROSPECTS_1_FROM_UT_RIGHTSIGNATURE_TITLE',
);
