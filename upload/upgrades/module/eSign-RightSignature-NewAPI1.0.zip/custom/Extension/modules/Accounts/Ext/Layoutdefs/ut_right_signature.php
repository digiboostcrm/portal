<?php
 // created: 2017-06-22 12:35:07
$layout_defs["Accounts"]["subpanel_setup"]['ut_rightsignature_accounts_1'] = array (
  'order' => 100,
  'module' => 'UT_RightSignature',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_UT_RIGHTSIGNATURE_ACCOUNTS_1_FROM_UT_RIGHTSIGNATURE_TITLE',
  'get_subpanel_data' => 'ut_rightsignature_accounts_1',
  'top_buttons' => 
  array ( ),
);