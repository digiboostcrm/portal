<?php
// created: 2017-06-22 12:35:07
$dictionary["Account"]["fields"]["ut_rightsignature_accounts_1"] = array (
  'name' => 'ut_rightsignature_accounts_1',
  'type' => 'link',
  'relationship' => 'ut_rightsignature_accounts_1',
  'source' => 'non-db',
  'module' => 'UT_RightSignature',
  'bean_name' => 'UT_RightSignature',
  'vname' => 'LBL_UT_RIGHTSIGNATURE_ACCOUNTS_1_FROM_UT_RIGHTSIGNATURE_TITLE',
);
