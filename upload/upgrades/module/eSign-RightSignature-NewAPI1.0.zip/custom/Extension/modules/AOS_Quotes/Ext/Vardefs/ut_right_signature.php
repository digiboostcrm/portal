<?php
// created: 2017-06-22 14:01:44
$dictionary["AOS_Quotes"]["fields"]["ut_rightsignature_aos_quotes_1"] = array (
  'name' => 'ut_rightsignature_aos_quotes_1',
  'type' => 'link',
  'relationship' => 'ut_rightsignature_aos_quotes_1',
  'source' => 'non-db',
  'module' => 'UT_RightSignature',
  'bean_name' => 'UT_RightSignature',
  'vname' => 'LBL_UT_RIGHTSIGNATURE_AOS_QUOTES_1_FROM_UT_RIGHTSIGNATURE_TITLE',
);
