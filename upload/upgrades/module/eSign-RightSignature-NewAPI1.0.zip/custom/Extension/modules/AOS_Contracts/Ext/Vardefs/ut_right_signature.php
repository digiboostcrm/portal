<?php
// created: 2017-06-22 14:00:05
$dictionary["AOS_Contracts"]["fields"]["ut_rightsignature_aos_contracts_1"] = array (
  'name' => 'ut_rightsignature_aos_contracts_1',
  'type' => 'link',
  'relationship' => 'ut_rightsignature_aos_contracts_1',
  'source' => 'non-db',
  'module' => 'UT_RightSignature',
  'bean_name' => 'UT_RightSignature',
  'vname' => 'LBL_UT_RIGHTSIGNATURE_AOS_CONTRACTS_1_FROM_UT_RIGHTSIGNATURE_TITLE',
);
