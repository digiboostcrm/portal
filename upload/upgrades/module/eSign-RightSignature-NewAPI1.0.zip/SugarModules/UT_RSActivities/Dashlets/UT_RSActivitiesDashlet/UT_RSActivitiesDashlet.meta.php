<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
  Created By : Urdhva Tech Pvt. Ltd.
  Created date : 02/20/2017
  Contact at : contact@urdhva-tech.com
  Web : www.urdhva-tech.com
  Skype : urdhvatech
*/

global $app_strings;

$dashletMeta['UT_RSActivitiesDashlet'] = array('module'		=> 'UT_RSActivities',
										  'title'       => translate('LBL_HOMEPAGE_TITLE', 'UT_RSActivities'), 
                                          'description' => 'A customizable view into UT_RSActivities',
                                          'category'    => 'Module Views');