<?php
/**
  Created By : Urdhva Tech Pvt. Ltd.
  Created date : 02/20/2017
  Contact at : contact@urdhva-tech.com
  Web : www.urdhva-tech.com
  Skype : urdhvatech
*/

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/UT_Signers/UT_Signers_sugar.php');
class UT_Signers extends UT_Signers_sugar {
	
	function __construct(){
		parent::__construct();
	}
	
}
?>