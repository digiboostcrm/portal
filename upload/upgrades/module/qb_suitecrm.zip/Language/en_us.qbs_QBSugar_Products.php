<?php
$mod_strings['LBL_QB_CREATED_TIME'] = 'QuickBooks Created Time';
$mod_strings['LBL_QB_MODIFIED_TIME'] = 'QuickBooks Modified Time';
$mod_strings['LBL_QBID'] = 'QuickBooks Id';
$mod_strings['LBL_ADD_TO_QB'] = 'Add to QuickBooks';
$mod_strings['LBL_QBEXPENSEACCOUNT'] = 'Quickbooks Expense Account';
$mod_strings['LBL_QBINCOMEACCOUNT'] = 'QuickBooks Income Account';
$mod_strings['LBL_SUGARQUICKBOOKS'] = 'Suite Quickbooks';
$mod_strings['LBL_QB_Qty_IN_HAND'] = 'Qty. in Hand';
$mod_strings['LBL_QB_START_DATE'] = 'Start Date';
$mod_strings['LBL_QBTYPE'] = 'Type';
$mod_strings['LBL_QBASSETACCOUNT'] = 'Asset Account';


