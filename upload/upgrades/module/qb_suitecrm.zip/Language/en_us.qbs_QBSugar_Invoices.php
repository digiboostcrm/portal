<?php
$mod_strings['LBL_QB_CREATED_TIME'] = 'QuickBooks Created Time';
$mod_strings['LBL_QB_MODIFIED_TIME'] = 'QuickBooks Modified Time';
$mod_strings['LBL_QBID'] = 'QuickBooks Id';
$mod_strings['LBL_ADD_TO_QB'] = 'Add to QuickBooks';
$mod_strings['LBL_SUGARQUICKBOOKS'] = 'Suite Quickbooks';
