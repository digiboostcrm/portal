<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_SalesItemLineDetail extends QuickBooks_IPP_Object
{
	
}
