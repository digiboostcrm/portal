<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);

function post_install()
{
    install_sql();
}


function install_sql()
{
    global $sugar_config, $db;

    if ($db->dbType == "mssql") {

        $GLOBALS['log']->fetal('db type is'.$db->dbType);
        $sql = "IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_modules]') AND type in (N'U'))
                                CREATE TABLE [dbo].notification_modules (
                                    id char(36) NOT NULL PRIMARY KEY,
                                    module varchar(255) NOT NULL,
                                    is_active SMALLINT NOT NULL,
                                    date_created datetime NOT NULL
                                )";
        $GLOBALS['log']->fetal('db type is'.print_r($sql,true));
        $result = $db->query($sql);

        $GLOBALS['log']->fetal('db type is'.print_r($result,true));
        $sql = "IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_user_preferences]') AND type in (N'U'))
                                CREATE TABLE [dbo].notification_user_preferences (
                                    user_id char(36) NOT NULL PRIMARY KEY,
                                    module_preference VARCHAR(MAX)
                                )";

        $result = $db->query($sql);

    } else {
        $sql = "CREATE TABLE IF NOT EXISTS notification_modules (
                id char(36) NOT NULL PRIMARY KEY,
                module varchar(255) NOT NULL,
                is_active tinyint(1) NOT NULL,
                date_created datetime NOT NULL
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8";

        $db->query($sql);

        $sql = "CREATE TABLE notification_user_preferences
            (
            user_id char(36) NOT NULL PRIMARY KEY,
            module_preference text
            )";

        $db->query($sql);
    }

}


?>