<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);

post_uninstall();

function post_uninstall()
{
    $files = array('custom/modules/setupCNLogic.php',
        'custom/modules/logic_hooks.php',
        'custom/Extension/modules/Administration/Ext/Administration/notification_setting.php',
        'custom/Extension/modules/Administration/Ext/Language/en_us.notification.lang.php',
        'custom/Extension/modules/Users/Ext/Language/en_us.notification.php',
        'custom/include/js/notification.js',
        'custom/include/js/unserialize.js',
        'custom/include/js/jquery-1.11.0.min.js',
        'custom/include/custom_notification_functions`.php',
    );
    foreach ($files as $file) {
        if (file_exists($file)) {
            unlink($file);
        }
    }
    global $sugar_version, $sugar_flavor;
    $re_sugar62 = '/(6\.2\.[0-9])/';
    $re_sugar63 = '/(6\.3\.[0-9])/';
    $re_sugarpro = '/(6\.5\.[0-9])/';
    // restore the original files


    // restore the original files
    $file = 'custom/modules/Users/logic_hooks_sdn_orig.php';
    $newfile = 'custom/modules/Users/logic_hooks.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    // backup existing files
    $file = 'custom/modules/logic_hooks_sdn_orig.php';
    $newfile = 'custom/modules/logic_hooks.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    if (preg_match($re_sugar62, $sugar_version) || preg_match($re_sugar63, $sugar_version)) {
        // restore the original files
        $file = 'modules/Users/EditView_sdn_orig.php';
        $newfile = 'modules/Users/EditView.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'modules/Users/DetailView_sdn_orig.php';
        $newfile = 'modules/Users/DetailView.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'modules/Users/EditView_sdn_orig.tpl';
        $newfile = 'modules/Users/EditView.tpl';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'modules/Users/DetailView_sdn_orig.tpl';
        $newfile = 'modules/Users/DetailView.tpl';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    } else if ($sugar_flavor == 'PRO' && preg_match($re_sugarpro, $sugar_version)) {
        // restore the original files
        $file = 'custom/modules/Users/views/view.detail_sdn_orig.php';
        $newfile = 'custom/modules/Users/views/view.detail.php';

        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
        // restore the original files
        $file = 'custom/modules/Users/views/view.edit_sdn_orig.php';
        $newfile = 'custom/modules/Users/views/view.edit.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'custom/modules/Users/metadata/editviewdefs_sdn_orig.php';
        $newfile = 'custom/modules/Users/metadata/editviewdefs.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'custom/modules/Users/metadata/detailviewdefs_sdn_orig.php';
        $newfile = 'custom/modules/Users/metadata/detailviewdefs.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    } else {
        // restore the original files
        $file = 'custom/modules/Users/views/view.detail_sdn_orig.php';
        $newfile = 'custom/modules/Users/views/view.detail.php';

        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
        // restore the original files
        $file = 'custom/modules/Users/views/view.edit_sdn_orig.php';
        $newfile = 'custom/modules/Users/views/view.edit.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'custom/modules/Users/metadata/editviewdefs_sdn_orig.php';
        $newfile = 'custom/modules/Users/metadata/editviewdefs.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // restore the original files
        $file = 'custom/modules/Users/metadata/detailviewdefs_sdn_orig.php';
        $newfile = 'custom/modules/Users/metadata/detailviewdefs.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    }

    $file = 'custom/modules/Users/language/en_us.lang_sdn_orig.php';
    $newfile = 'custom/modules/Users/language/en_us.lang.php';

    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }


}

global $sugar_config, $db;
if ($_REQUEST['remove_tables'] == 'true') {
    if($db->dbType == 'mssql'){
        $sql_modules = "IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_modules]') AND type in (N'U'))
DROP TABLE [dbo].notification_modules";
        $sql_preference = "IF EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_user_preferences]') AND type in (N'U'))
DROP TABLE [dbo].notification_user_preferences";
        $db->query($sql_modules);
        $db->query($sql_preference);
    }else{
        $sql_modules = "DROP table notification_modules";
        $sql_preference = "DROP table notification_user_preferences";
        $db->query($sql_modules);
        $db->query($sql_preference);
        $db->query($sql_preference);
    }

}


