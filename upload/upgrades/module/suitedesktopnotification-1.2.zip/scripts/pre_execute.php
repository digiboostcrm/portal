<?php

if (!defined('sugarEntry'))
    define('sugarEntry', true);
pre_execute();

function pre_execute()
{

    global $sugar_version, $sugar_flavor;
    $re_sugar62 = '/(6\.2\.[0-9])/';
    $re_sugar63 = '/(6\.3\.[0-9])/';
    $re_sugarpro = '/(6\.5\.[0-9])/';

    // backup existing files

    // backup existing files
    $file = 'custom/modules/Users/logic_hooks.php';
    $newfile = 'custom/modules/Users/logic_hooks_sdn_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    // backup existing files
    $file = 'custom/modules/Users/language/en_us.lang.php';
    $newfile = 'custom/modules/Users/language/en_us.lang_sdn_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    // backup existing files
    $file = 'custom/modules/logic_hooks.php';
    $newfile = 'custom/modules/logic_hooks_sdn_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }


    if (preg_match($re_sugar62, $sugar_version) || preg_match($re_sugar63, $sugar_version)) {
        // backup existing files
        $file = 'modules/Users/EditView.php';
        $newfile = 'modules/Users/EditView_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'modules/Users/DetailView.php';
        $newfile = 'modules/Users/DetailView_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'modules/Users/EditView.tpl';
        $newfile = 'modules/Users/EditView_sdn_orig.tpl';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'modules/Users/DetailView.tpl';
        $newfile = 'modules/Users/DetailView_sdn_orig.tpl';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    } else if ($sugar_flavor == 'PRO' && preg_match($re_sugarpro, $sugar_version)) {
        // backup existing files
        $file = 'custom/modules/Users/views/view.detail.php';
        $newfile = 'custom/modules/Users/views/view.detail_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/views/view.edit.php';
        $newfile = 'custom/modules/Users/views/view.edit_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/metadata/editviewdefs.php';
        $newfile = 'custom/modules/Users/metadata/editviewdefs_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/metadata/detailviewdefs.php';
        $newfile = 'custom/modules/Users/metadata/detailviewdefs_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    } else {
        // backup existing files
        $file = 'custom/modules/Users/views/view.detail.php';
        $newfile = 'custom/modules/Users/views/view.detail_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/views/view.edit.php';
        $newfile = 'custom/modules/Users/views/view.edit_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/metadata/editviewdefs.php';
        $newfile = 'custom/modules/Users/metadata/editviewdefs_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }

        // backup existing files
        $file = 'custom/modules/Users/metadata/detailviewdefs.php';
        $newfile = 'custom/modules/Users/metadata/detailviewdefs_sdn_orig.php';
        if (file_exists($file)) {
            if (!rename($file, $newfile))
                echo "failed to rename $file...\n";
        }
    }
}
