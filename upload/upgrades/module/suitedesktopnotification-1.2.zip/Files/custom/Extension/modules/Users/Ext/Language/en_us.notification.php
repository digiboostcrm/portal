<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_NOTIFICATION_MODULE_INFORMATION'] = 'Desktop Notification Modules';

?>