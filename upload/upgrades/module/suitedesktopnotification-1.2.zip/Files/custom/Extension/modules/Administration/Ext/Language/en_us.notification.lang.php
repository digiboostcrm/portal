<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_ADMIN_MODULE_NAME'] = 'Administration';
$mod_strings['LBL_NOTIFICATION_CONFIGURE_MODULE_LINK'] = 'Configure Notification Modules';
$mod_strings['LBL_NOTIFICATION_CONFIGURE_MODULE_LINK_DESC'] = 'Enable/Disable modules for Desktop Notification.';
$mod_strings['LBL_NOTIFICATION_DESC'] = 'Configure which modules are available to users for Desktop Notification.';
$mod_strings['LBL_NOTIFICATION_TITLE'] = 'Desktop Notification';

?>
