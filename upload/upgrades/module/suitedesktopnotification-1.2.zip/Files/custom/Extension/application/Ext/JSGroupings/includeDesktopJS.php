<?php
$js_groupings[] = $sugar_grp1 = array_merge($sugar_grp1,    array(
    'custom/include/modules/bc_notification/js/includejs.js' => 'include/javascript/sugar_grp1.js',
    )
);

