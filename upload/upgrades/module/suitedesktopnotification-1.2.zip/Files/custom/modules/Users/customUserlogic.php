<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class customUserlogic
{

    function setNotificationModules(&$bean, $event, $arguments)
    {
        if(empty($_REQUEST['subpanel_field_name'])) {
            require_once 'custom/include/custom_notification_functions.php';
            $module_list = array();
            $modules = $_REQUEST['chkmodule'];
            $is_active = $_REQUEST['is_active'];
            foreach ($modules as $key => $module) {
                $module_list[$module] = isset($is_active[$module]) ? 1 : 0;
            }

            setUNModulepreference($bean->id, $module_list);
        }
    }


}
