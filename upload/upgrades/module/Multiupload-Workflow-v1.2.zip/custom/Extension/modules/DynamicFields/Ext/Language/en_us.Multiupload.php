<?php

$mod_strings['COLUMN_TITLE_MULTIUPLOAD'] = 'Multiupload';
