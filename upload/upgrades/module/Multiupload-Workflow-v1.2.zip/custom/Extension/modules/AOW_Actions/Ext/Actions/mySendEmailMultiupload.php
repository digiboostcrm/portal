<?php

$aow_actions_list[]='SendEmailMultiupload';