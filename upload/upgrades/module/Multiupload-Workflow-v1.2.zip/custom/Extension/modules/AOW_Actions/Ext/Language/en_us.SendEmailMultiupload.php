<?php

$mod_strings['LBL_SENDEMAILMULTIUPLOAD'] = 'Send Email with Multiupload Attachments';
$mod_strings['LBL_MULTIUPLOAD_FIELD'] = 'Multiupload Field';