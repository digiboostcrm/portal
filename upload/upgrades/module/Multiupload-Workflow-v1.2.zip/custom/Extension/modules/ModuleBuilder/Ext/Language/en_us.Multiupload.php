<?php
$mod_strings['fieldTypes']['Multiupload'] = 'Multiupload';
?>