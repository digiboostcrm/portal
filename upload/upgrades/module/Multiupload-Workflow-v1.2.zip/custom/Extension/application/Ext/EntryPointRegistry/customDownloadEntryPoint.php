<?php

$entry_point_registry['download2'] = array('file' => 'download2.php', 'auth' => false);