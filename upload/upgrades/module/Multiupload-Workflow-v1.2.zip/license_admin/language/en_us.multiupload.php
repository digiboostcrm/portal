<?php

$mod_strings['LBL_MULTIUPLOAD'] = 'Multiupload Add-on';
$mod_strings['LBL_MULTIUPLOAD_LICENSE_TITLE'] = 'License Configuration';
$mod_strings['LBL_MULTIUPLOAD_LICENSE'] = 'Manage and configure the license for this add-on';
