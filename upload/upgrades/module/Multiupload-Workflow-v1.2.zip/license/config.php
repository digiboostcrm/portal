<?php

$outfitters_config = array(
    'name' => 'multiupload-files-with-workflow', 
    'shortname' => 'multiupload-files-with-workflow', 
    'public_key' => 'bdeecc773c3a6b506ef966e0c5a403d0', 
    'api_url' => 'https://store.suitecrm.com/api/v1',
    'validate_users' => false,
    'manage_licensed_users' => false, 
    'validation_frequency' => 'weekly',
    'continue_url' => '', 
);

