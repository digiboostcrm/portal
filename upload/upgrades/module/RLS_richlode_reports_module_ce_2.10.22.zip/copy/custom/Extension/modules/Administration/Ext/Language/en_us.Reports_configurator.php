<?php


$mod_strings['LBL_MANAGE_REPORT_CONFIG'] = 'Reports parameters';
$mod_strings['LBL_REPORT_CONFIG'] = 'Set reports parameters';
$mod_strings['LBL_REPORT_CONFIG_DESC'] = 'Configure reports parameters';
$mod_strings['LBL_REPORT_CONFIG_TITLE'] = 'Reports';
