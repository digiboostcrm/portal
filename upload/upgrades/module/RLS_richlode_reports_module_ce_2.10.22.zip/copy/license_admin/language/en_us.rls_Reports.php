<?php

$mod_strings['LBL_REPORTLICENSEADDON'] = 'License Add-on';
$mod_strings['LBL_REPORTLICENSEADDON_LICENSE_TITLE'] = 'Reports Module License Configuration';
$mod_strings['LBL_REPORTLICENSEADDON_LICENSE'] = 'Manage and configure license for <a href="http://www.richlodesolutions.com" target="_blank">Richlode Solutions</a> Reports add-on. ';
