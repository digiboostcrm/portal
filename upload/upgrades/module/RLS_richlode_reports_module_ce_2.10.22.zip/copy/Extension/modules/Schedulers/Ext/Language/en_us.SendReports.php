<?php
$mod_strings['LBL_SENDREPORTS_JOB'] = 'Send Reports';