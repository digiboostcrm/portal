<?php
// created: 2015-06-16 11:43:23
$dictionary["RLS_Scheduling_Reports"]["fields"]["rls_scheduling_reports_rls_reports"] = array (
  'name' => 'rls_scheduling_reports_rls_reports',
  'type' => 'link',
  'relationship' => 'rls_scheduling_reports_rls_reports',
  'source' => 'non-db',
  'module' => 'rls_Reports',
  'bean_name' => 'rls_Reports',
  'vname' => 'LBL_RLS_SCHEDULING_REPORTS_RLS_REPORTS_FROM_RLS_REPORTS_TITLE',
);
