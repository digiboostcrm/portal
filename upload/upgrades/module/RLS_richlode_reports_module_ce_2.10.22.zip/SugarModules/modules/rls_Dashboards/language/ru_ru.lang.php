<?php

$mod_strings = array (
  'LBL_ARE_YOU_SURE' => 'Вы уверены что хотите удалить?',
);
