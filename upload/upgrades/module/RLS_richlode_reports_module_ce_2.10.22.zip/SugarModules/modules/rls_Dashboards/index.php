<?php
$_REQUEST['module'] = 'rls_Reports';
ControllerFactory::getController('rls_Reports')->dashboardIndex();

