/**
 * The object for Reports Wizard
 * 
 * */
var Wizard = {};
