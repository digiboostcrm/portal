﻿<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$license_strings = array (
'LBL_STEPS_TO_LOCATE_KEY_TITLE' => 'Чтобы найти ключ',
'LBL_STEPS_TO_LOCATE_KEY' => '1. Введите логин и пароль, чтобы <a href="https://www.sugaroutfitters.com" target="_blank">SugarOutfitters</a><br/>2. к Account->Purchases</br>3. Найдите ключ на покупку этого дополнения<br/>4. Вставить в окне License Key ниже<br/>5. Нажмите на "Validate"',
'LBL_LICENSE_KEY' => 'Лицензионный ключ',
'LBL_CURRENT_USERS' => 'Текущий Граф Пользователь',
'LBL_LICENSED_USERS' => 'Лицензия Граф Пользователь',
'LBL_VALIDATE_LABEL' => 'утверждать',
'LBL_VALIDATED_LABEL' => 'Утвержденные',
'LBL_MESSAGE_ERROR' => 'rls_Reports нет лицензионного ключа',
);
