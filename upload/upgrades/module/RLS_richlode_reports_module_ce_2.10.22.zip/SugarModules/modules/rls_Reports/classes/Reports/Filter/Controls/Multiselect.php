<?php
namespace Reports\Filter\Controls;

/**
 * This class is intended for handling Control of Multiselect type
 * 
 * @package Reports.Filter.Controls
 * */
class Multiselect extends Dropdown
{

}
