<?php
namespace Reports\Configurator;
/**
 * @access public
 * @author Richlode Solutions
 * @package classes.Reports.Configurator
 */
class Grid {
}
?>
