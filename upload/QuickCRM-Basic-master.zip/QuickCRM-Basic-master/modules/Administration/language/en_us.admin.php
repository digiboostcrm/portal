<?php

$mod_strings['LBL_UPDATE_QUICKCRM_TITLE'] = "QuickCRM Update";
$mod_strings['LBL_UPDATE_QUICKCRM'] = "Rebuild fields definition";
$mod_strings['LBL_QUICKCRM'] = 'QuickCRM Mobile';
$mod_strings['LBL_CONFIG_QUICKCRM_TITLE'] = "Configuration of QuickCRM Mobile";
$mod_strings['LBL_CONFIG_QUICKCRM'] = "Definition of visible modules and fields";
$mod_strings['LBL_UPDATE_MSG'] = '<strong>Application updated for QuickCRM on mobile</strong><br/>You can access the mobile version at:';
$mod_strings['LBL_ERR_DIR_MSG'] = 'Some files could not be created. Please check write access permissions for: ';


